import mysql from 'mysql2/promise';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';

dotenv.config();

const DB_HOST = process.env.DB_HOST || 'localhost';
const DB_PORT = process.env.DB_PORT || 3306;
const DB_USER = process.env.DB_USER || 'root';
const DB_PASSWORD = process.env.DB_PASSWORD || '';
const DB_NAME = process.env.DB_NAME || 'student_management';

let isUsingMySQL = false;
let mysqlPool = null;

// JSON File DB state
const dbFilePath = path.join(process.cwd(), 'database', 'students.json');
let studentsStore = [];
let nextId = 1;

// Initial sample seed data
const initialSampleStudents = [
  { id: 1, student_id: 'CS202601', full_name: 'Aarav Sharma', email: 'aarav.sharma@example.com', phone: '9876543210', gender: 'Male', dob: '2004-05-15', branch: 'Computer Science', semester: 5, section: 'A', address: '102 Green Park Avenue, New Delhi', created_at: '2026-01-10T08:00:00.000Z' },
  { id: 2, student_id: 'IT202602', full_name: 'Priya Patel', email: 'priya.patel@example.com', phone: '9876543211', gender: 'Female', dob: '2003-08-22', branch: 'Information Technology', semester: 6, section: 'B', address: '45 MG Road, Bengaluru, Karnataka', created_at: '2026-01-11T09:15:00.000Z' },
  { id: 3, student_id: 'EC202603', full_name: 'Rohan Verma', email: 'rohan.verma@example.com', phone: '9876543212', gender: 'Male', dob: '2004-01-10', branch: 'Electronics & Comm', semester: 4, section: 'A', address: '78 Lake View Enclave, Hyderabad', created_at: '2026-01-12T10:30:00.000Z' },
  { id: 4, student_id: 'ME202604', full_name: 'Ananya Roy', email: 'ananya.roy@example.com', phone: '9876543213', gender: 'Female', dob: '2005-03-30', branch: 'Mechanical Eng', semester: 3, section: 'C', address: '12 Salt Lake Sector V, Kolkata', created_at: '2026-01-13T11:45:00.000Z' },
  { id: 5, student_id: 'CE202605', full_name: 'Vikram Singh', email: 'vikram.singh@example.com', phone: '9876543214', gender: 'Male', dob: '2002-11-05', branch: 'Civil Eng', semester: 8, section: 'A', address: '304 Park Street, Jaipur, Rajasthan', created_at: '2026-01-14T12:00:00.000Z' },
  { id: 6, student_id: 'CS202606', full_name: 'Sneha Kulkarni', email: 'sneha.kulkarni@example.com', phone: '9876543215', gender: 'Female', dob: '2004-09-18', branch: 'Computer Science', semester: 5, section: 'B', address: '56 FC Road, Pune, Maharashtra', created_at: '2026-01-15T13:20:00.000Z' },
  { id: 7, student_id: 'IT202607', full_name: 'Aditya Nair', email: 'aditya.nair@example.com', phone: '9876543216', gender: 'Male', dob: '2005-02-14', branch: 'Information Technology', semester: 2, section: 'A', address: '89 Marine Drive, Kochi, Kerala', created_at: '2026-01-16T14:10:00.000Z' },
  { id: 8, student_id: 'EC202608', full_name: 'Kavya Reddy', email: 'kavya.reddy@example.com', phone: '9876543217', gender: 'Female', dob: '2003-12-01', branch: 'Electronics & Comm', semester: 7, section: 'B', address: '201 Jubilee Hills, Hyderabad', created_at: '2026-01-17T15:00:00.000Z' },
  { id: 9, student_id: 'CS202609', full_name: 'Siddharth Gupta', email: 'siddharth.gupta@example.com', phone: '9876543218', gender: 'Male', dob: '2004-07-25', branch: 'Computer Science', semester: 3, section: 'A', address: '15 Hazratganj, Lucknow, UP', created_at: '2026-01-18T16:40:00.000Z' },
  { id: 10, student_id: 'ME202610', full_name: 'Meera Joshi', email: 'meera.joshi@example.com', phone: '9876543219', gender: 'Female', dob: '2005-06-12', branch: 'Mechanical Eng', semester: 1, section: 'A', address: '40 Race Course Road, Ahmedabad, Gujarat', created_at: '2026-01-19T17:30:00.000Z' }
];

function saveStore() {
  try {
    const dir = path.dirname(dbFilePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(dbFilePath, JSON.stringify(studentsStore, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to persist student records to disk:', err);
  }
}

let isDbInitialized = false;

export async function initDatabase() {
  if (isDbInitialized) return;
  isDbInitialized = true;
  // 1. Attempt MySQL connection first
  try {
    const tempPool = mysql.createPool({
      host: DB_HOST,
      port: Number(DB_PORT),
      user: DB_USER,
      password: DB_PASSWORD,
      waitForConnections: true,
      connectionLimit: 5,
      connectTimeout: 1500
    });

    const connection = await tempPool.getConnection();
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`;`);
    connection.release();
    await tempPool.end();

    mysqlPool = mysql.createPool({
      host: DB_HOST,
      port: Number(DB_PORT),
      user: DB_USER,
      password: DB_PASSWORD,
      database: DB_NAME,
      waitForConnections: true,
      connectionLimit: 10
    });

    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS students (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id VARCHAR(20) NOT NULL UNIQUE,
        full_name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        phone VARCHAR(15) NOT NULL,
        gender VARCHAR(20) NOT NULL,
        dob DATE NOT NULL,
        branch VARCHAR(50) NOT NULL,
        semester INT NOT NULL,
        section VARCHAR(10) NOT NULL,
        address TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `;
    await mysqlPool.query(createTableSQL);

    const [rows] = await mysqlPool.query('SELECT COUNT(*) as count FROM students');
    if (rows[0].count === 0) {
      for (const s of initialSampleStudents) {
        await mysqlPool.query(
          `INSERT INTO students (student_id, full_name, email, phone, gender, dob, branch, semester, section, address)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [s.student_id, s.full_name, s.email, s.phone, s.gender, s.dob, s.branch, s.semester, s.section, s.address]
        );
      }
      console.log('✅ Initialized MySQL database with sample student records.');
    }

    isUsingMySQL = true;
    console.log(`✅ Connected to MySQL database "${DB_NAME}" on ${DB_HOST}:${DB_PORT}`);
    return;
  } catch (err) {
    console.log(`ℹ️ MySQL database unavailable (${err.message}). Using persistent JSON File Engine for instant execution.`);
  }

  // 2. Persistent File Engine Fallback (Pure JS, zero binary dependencies)
  const dir = path.dirname(dbFilePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  if (fs.existsSync(dbFilePath)) {
    try {
      const data = fs.readFileSync(dbFilePath, 'utf-8');
      studentsStore = JSON.parse(data);
    } catch (e) {
      studentsStore = [...initialSampleStudents];
      saveStore();
    }
  } else {
    studentsStore = [...initialSampleStudents];
    saveStore();
  }

  const maxExistingId = studentsStore.reduce((max, s) => Math.max(max, Number(s.id) || 0), 0);
  nextId = maxExistingId + 1;

  console.log(`✅ Running with Persistent File Engine at ${dbFilePath} (${studentsStore.length} records loaded).`);
}

// Unified Query Handler for MySQL or File Engine
export async function dbQuery(sql, params = []) {
  if (isUsingMySQL && mysqlPool) {
    const [rows] = await mysqlPool.query(sql, params);
    return rows;
  }

  const sqlLower = sql.toLowerCase();

  // 1. GROUP BY branch
  if (sqlLower.includes('group by branch')) {
    const counts = {};
    for (const s of studentsStore) {
      counts[s.branch] = (counts[s.branch] || 0) + 1;
    }
    const result = Object.keys(counts).map(branch => ({
      branch,
      count: counts[branch]
    }));
    result.sort((a, b) => b.count - a.count);
    return result;
  }

  // 2. GROUP BY semester
  if (sqlLower.includes('group by semester')) {
    const counts = {};
    for (const s of studentsStore) {
      counts[s.semester] = (counts[s.semester] || 0) + 1;
    }
    const result = Object.keys(counts).map(sem => ({
      semester: Number(sem),
      count: counts[sem]
    }));
    result.sort((a, b) => a.semester - b.semester);
    return result;
  }

  // 3. SELECT COUNT(*) as total FROM students WHERE ...
  if (sqlLower.includes('count(*) as total') || (sqlLower.includes('count(*) as count') && !sqlLower.includes('group by'))) {
    const filtered = filterStudents(sql, params);
    return [{ total: filtered.length, count: filtered.length }];
  }

  // 4. Default Select with filter, search, sort, pagination
  let results = filterStudents(sql, params);

  // Sorting
  if (sqlLower.includes('order by created_at desc') || sqlLower.includes('order by id desc')) {
    results.sort((a, b) => Number(b.id) - Number(a.id));
  }

  // Pagination (LIMIT & OFFSET)
  if (sqlLower.includes('limit')) {
    let limit = 10;
    let offset = 0;

    const limitMatch = sqlLower.match(/limit\s+(\d+)/);
    const offsetMatch = sqlLower.match(/offset\s+(\d+)/);

    if (params.length >= 2 && sql.includes('?')) {
      limit = Number(params[params.length - 2]);
      offset = Number(params[params.length - 1]);
    } else if (params.length === 1 && sql.includes('?')) {
      limit = Number(params[0]);
    } else if (limitMatch) {
      limit = parseInt(limitMatch[1], 10);
      if (offsetMatch) {
        offset = parseInt(offsetMatch[1], 10);
      }
    }

    if (!isNaN(limit) && !isNaN(offset)) {
      results = results.slice(offset, offset + limit);
    }
  }

  return results;
}

export async function dbGet(sql, params = []) {
  if (isUsingMySQL && mysqlPool) {
    const [rows] = await mysqlPool.query(sql, params);
    return rows[0] || null;
  }

  const sqlLower = sql.trim().toLowerCase();

  if (sqlLower.includes('where id = ? or student_id = ?')) {
    const val = String(params[0]);
    return studentsStore.find(s => String(s.id) === val || String(s.student_id).toUpperCase() === val.toUpperCase()) || null;
  }

  if (sqlLower.includes('where student_id = ? and id != ?')) {
    const [stId, excludeId] = params;
    return studentsStore.find(s => String(s.student_id).toUpperCase() === String(stId).toUpperCase() && Number(s.id) !== Number(excludeId)) || null;
  }

  if (sqlLower.includes('where student_id = ?')) {
    const stId = String(params[0]);
    return studentsStore.find(s => String(s.student_id).toUpperCase() === stId.toUpperCase()) || null;
  }

  if (sqlLower.includes('where email = ? and id != ?')) {
    const [email, excludeId] = params;
    return studentsStore.find(s => String(s.email).toLowerCase() === String(email).toLowerCase() && Number(s.id) !== Number(excludeId)) || null;
  }

  if (sqlLower.includes('where email = ?')) {
    const email = String(params[0]);
    return studentsStore.find(s => String(s.email).toLowerCase() === email.toLowerCase()) || null;
  }

  if (sqlLower.includes('where id = ?')) {
    const id = Number(params[0]);
    return studentsStore.find(s => Number(s.id) === id) || null;
  }

  const results = await dbQuery(sql, params);
  return results[0] || null;
}

export async function dbExecute(sql, params = []) {
  if (isUsingMySQL && mysqlPool) {
    const [result] = await mysqlPool.execute(sql, params);
    return { insertId: result.insertId, affectedRows: result.affectedRows };
  }

  const sqlClean = sql.trim().toLowerCase();

  // INSERT INTO students
  if (sqlClean.includes('insert into')) {
    const [student_id, full_name, email, phone, gender, dob, branch, semester, section, address] = params;
    
    const newStudent = {
      id: nextId++,
      student_id: String(student_id),
      full_name: String(full_name),
      email: String(email),
      phone: String(phone),
      gender: String(gender),
      dob: String(dob),
      branch: String(branch),
      semester: Number(semester),
      section: String(section),
      address: String(address),
      created_at: new Date().toISOString()
    };

    studentsStore.push(newStudent);
    saveStore();

    return { insertId: newStudent.id, affectedRows: 1, student: newStudent };
  }

  // UPDATE students
  if (sqlClean.includes('update')) {
    const id = Number(params[params.length - 1]);
    const index = studentsStore.findIndex(s => Number(s.id) === id);

    if (index !== -1) {
      const [student_id, full_name, email, phone, gender, dob, branch, semester, section, address] = params;
      
      studentsStore[index] = {
        ...studentsStore[index],
        student_id: String(student_id),
        full_name: String(full_name),
        email: String(email),
        phone: String(phone),
        gender: String(gender),
        dob: String(dob),
        branch: String(branch),
        semester: Number(semester),
        section: String(section),
        address: String(address)
      };

      saveStore();
      return { insertId: id, affectedRows: 1, student: studentsStore[index] };
    }

    return { insertId: id, affectedRows: 0 };
  }

  // DELETE FROM students
  if (sqlClean.includes('delete from')) {
    const id = Number(params[0]);
    const initialLen = studentsStore.length;
    studentsStore = studentsStore.filter(s => Number(s.id) !== id);
    const affected = initialLen - studentsStore.length;

    if (affected > 0) {
      saveStore();
    }

    return { insertId: id, affectedRows: affected };
  }

  return { insertId: 0, affectedRows: 0 };
}

// Helper function to filter array according to SQL params
function filterStudents(sql, params) {
  const sqlLower = sql.toLowerCase();
  let list = [...studentsStore];

  // Search filter
  let paramIdx = 0;
  if (sqlLower.includes('full_name like') || sqlLower.includes('student_id like')) {
    const rawSearch = params[paramIdx] || '';
    const searchTerm = String(rawSearch).replace(/%/g, '').toLowerCase();
    paramIdx += 3; // consume 3 search terms

    if (searchTerm) {
      list = list.filter(s => 
        String(s.full_name).toLowerCase().includes(searchTerm) ||
        String(s.student_id).toLowerCase().includes(searchTerm) ||
        String(s.email).toLowerCase().includes(searchTerm)
      );
    }
  }

  // Branch filter
  if (sqlLower.includes('branch = ?')) {
    const branchVal = params[paramIdx];
    paramIdx++;
    if (branchVal && branchVal !== 'all') {
      list = list.filter(s => String(s.branch).toLowerCase() === String(branchVal).toLowerCase());
    }
  }

  // Semester filter
  if (sqlLower.includes('semester = ?')) {
    const semVal = params[paramIdx];
    paramIdx++;
    if (semVal && semVal !== 'all') {
      list = list.filter(s => Number(s.semester) === Number(semVal));
    }
  }

  return list;
}

export function getDatabaseType() {
  return isUsingMySQL ? 'MySQL Database' : 'JSON File Engine (Active)';
}
