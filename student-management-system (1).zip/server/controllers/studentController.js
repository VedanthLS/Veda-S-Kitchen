import { dbQuery, dbGet, dbExecute, getDatabaseType } from '../db.js';

/**
 * Student Management Controller
 * Handles all CRUD operations and analytics for Student records.
 */

// Helper function to validate email format
const isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Helper function to validate phone number format (10-15 digits)
const isValidPhone = (phone) => {
  const phoneRegex = /^[0-9+\-\s]{10,15}$/;
  return phoneRegex.test(phone);
};

/**
 * GET /api/stats
 * Fetches dashboard analytical metrics:
 * - Total student count
 * - Breakdown by Branch
 * - Breakdown by Semester
 * - 5 Most Recent Students
 */
export async function getDashboardStats(req, res) {
  try {
    // 1. Total Students
    const totalRow = await dbGet('SELECT COUNT(*) as total FROM students');
    const totalStudents = totalRow ? totalRow.total : 0;

    // 2. Students by Branch
    const branchRows = await dbQuery(
      'SELECT branch, COUNT(*) as count FROM students GROUP BY branch ORDER BY count DESC'
    );

    // 3. Students by Semester
    const semesterRows = await dbQuery(
      'SELECT semester, COUNT(*) as count FROM students GROUP BY semester ORDER BY semester ASC'
    );

    // 4. Recent Students (latest 5)
    const recentStudents = await dbQuery(
      'SELECT * FROM students ORDER BY created_at DESC LIMIT 5'
    );

    return res.status(200).json({
      success: true,
      data: {
        totalStudents,
        branchStats: branchRows,
        semesterStats: semesterRows,
        recentStudents,
        databaseType: getDatabaseType()
      }
    });
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch dashboard metrics from database.'
    });
  }
}

/**
 * GET /api/students
 * Fetches student list with search, filter (branch/semester), and pagination.
 */
export async function getAllStudents(req, res) {
  try {
    const { search, branch, semester, page = 1, limit = 10 } = req.query;

    let whereClauses = [];
    let params = [];

    // Search by Name or Student ID or Email
    if (search && search.trim() !== '') {
      whereClauses.push('(full_name LIKE ? OR student_id LIKE ? OR email LIKE ?)');
      const searchTerm = `%${search.trim()}%`;
      params.push(searchTerm, searchTerm, searchTerm);
    }

    // Filter by Branch
    if (branch && branch !== 'all') {
      whereClauses.push('branch = ?');
      params.push(branch);
    }

    // Filter by Semester
    if (semester && semester !== 'all') {
      whereClauses.push('semester = ?');
      params.push(Number(semester));
    }

    const whereSQL = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

    // Count Total Records for Pagination
    const countQuery = `SELECT COUNT(*) as total FROM students ${whereSQL}`;
    const countRow = await dbGet(countQuery, params);
    const total = countRow ? countRow.total : 0;

    // Calculate Pagination
    const pageNum = Math.max(1, parseInt(page, 10));
    const limitNum = Math.max(1, parseInt(limit, 10));
    const offset = (pageNum - 1) * limitNum;
    const totalPages = Math.ceil(total / limitNum) || 1;

    // Fetch Paginated Records
    const dataQuery = `SELECT * FROM students ${whereSQL} ORDER BY id DESC LIMIT ? OFFSET ?`;
    const queryParams = [...params, limitNum, offset];

    const students = await dbQuery(dataQuery, queryParams);

    return res.status(200).json({
      success: true,
      data: students,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages
      }
    });
  } catch (error) {
    console.error('Error fetching students:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve student records.'
    });
  }
}

/**
 * GET /api/students/:id
 * Fetches single student record by Primary Key ID or Student ID.
 */
export async function getStudentById(req, res) {
  try {
    const { id } = req.params;

    // Search by numeric primary key OR student_id string
    const student = await dbGet(
      'SELECT * FROM students WHERE id = ? OR student_id = ?',
      [id, id]
    );

    if (!student) {
      return res.status(404).json({
        success: false,
        message: 'Student record not found.'
      });
    }

    return res.status(200).json({
      success: true,
      data: student
    });
  } catch (error) {
    console.error('Error fetching student by ID:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve student profile.'
    });
  }
}

/**
 * POST /api/students
 * C – CREATE: Adds a new student record to the database.
 */
export async function createStudent(req, res) {
  try {
    const {
      student_id,
      full_name,
      email,
      phone,
      gender,
      dob,
      branch,
      semester,
      section,
      address
    } = req.body;

    // 1. Required Fields Validation
    if (
      !student_id ||
      !full_name ||
      !email ||
      !phone ||
      !gender ||
      !dob ||
      !branch ||
      !semester ||
      !section ||
      !address
    ) {
      return res.status(400).json({
        success: false,
        message: 'All fields are required. Please complete all form inputs.'
      });
    }

    // 2. Email & Phone Validation
    if (!isValidEmail(email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email address format.'
      });
    }

    if (!isValidPhone(phone)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid phone number format. Must be 10–15 digits.'
      });
    }

    // 3. Semester Range Validation
    const semNum = Number(semester);
    if (isNaN(semNum) || semNum < 1 || semNum > 8) {
      return res.status(400).json({
        success: false,
        message: 'Semester must be an integer between 1 and 8.'
      });
    }

    // 4. Check Unique Constraints (Student ID & Email)
    const existingStudentId = await dbGet('SELECT id FROM students WHERE student_id = ?', [student_id]);
    if (existingStudentId) {
      return res.status(400).json({
        success: false,
        message: `Student ID "${student_id}" is already registered. Student ID must be unique.`
      });
    }

    const existingEmail = await dbGet('SELECT id FROM students WHERE email = ?', [email]);
    if (existingEmail) {
      return res.status(400).json({
        success: false,
        message: `Email "${email}" is already in use. Email must be unique.`
      });
    }

    // 5. Execute Insert
    const insertSQL = `
      INSERT INTO students (student_id, full_name, email, phone, gender, dob, branch, semester, section, address)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const result = await dbExecute(insertSQL, [
      student_id.trim().toUpperCase(),
      full_name.trim(),
      email.trim().toLowerCase(),
      phone.trim(),
      gender,
      dob,
      branch,
      semNum,
      section.trim().toUpperCase(),
      address.trim()
    ]);

    const newStudent = result.student || (await dbGet('SELECT * FROM students WHERE student_id = ?', [student_id.trim().toUpperCase()]));

    return res.status(201).json({
      success: true,
      message: 'Student record created successfully!',
      data: newStudent
    });
  } catch (error) {
    console.error('Error creating student:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while adding student record.'
    });
  }
}

/**
 * PUT /api/students/:id
 * U – UPDATE: Modifies existing student details.
 */
export async function updateStudent(req, res) {
  try {
    const { id } = req.params;
    const {
      student_id,
      full_name,
      email,
      phone,
      gender,
      dob,
      branch,
      semester,
      section,
      address
    } = req.body;

    // 1. Check if student exists
    const existing = await dbGet('SELECT * FROM students WHERE id = ?', [id]);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: 'Student record not found.'
      });
    }

    // 2. Validate Input Fields
    if (
      !student_id ||
      !full_name ||
      !email ||
      !phone ||
      !gender ||
      !dob ||
      !branch ||
      !semester ||
      !section ||
      !address
    ) {
      return res.status(400).json({
        success: false,
        message: 'All fields are required.'
      });
    }

    if (!isValidEmail(email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email address format.'
      });
    }

    if (!isValidPhone(phone)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid phone number format.'
      });
    }

    const semNum = Number(semester);
    if (isNaN(semNum) || semNum < 1 || semNum > 8) {
      return res.status(400).json({
        success: false,
        message: 'Semester must be between 1 and 8.'
      });
    }

    // 3. Ensure updated Student ID & Email don't collide with OTHER students
    const checkIdCollision = await dbGet(
      'SELECT id FROM students WHERE student_id = ? AND id != ?',
      [student_id, id]
    );
    if (checkIdCollision) {
      return res.status(400).json({
        success: false,
        message: `Student ID "${student_id}" is already assigned to another student.`
      });
    }

    const checkEmailCollision = await dbGet(
      'SELECT id FROM students WHERE email = ? AND id != ?',
      [email, id]
    );
    if (checkEmailCollision) {
      return res.status(400).json({
        success: false,
        message: `Email "${email}" is already used by another student.`
      });
    }

    // 4. Update Database
    const updateSQL = `
      UPDATE students 
      SET student_id = ?, full_name = ?, email = ?, phone = ?, gender = ?, dob = ?, branch = ?, semester = ?, section = ?, address = ?
      WHERE id = ?
    `;

    await dbExecute(updateSQL, [
      student_id.trim().toUpperCase(),
      full_name.trim(),
      email.trim().toLowerCase(),
      phone.trim(),
      gender,
      dob,
      branch,
      semNum,
      section.trim().toUpperCase(),
      address.trim(),
      id
    ]);

    const updatedStudent = await dbGet('SELECT * FROM students WHERE id = ?', [id]);

    return res.status(200).json({
      success: true,
      message: 'Student record updated successfully!',
      data: updatedStudent
    });
  } catch (error) {
    console.error('Error updating student:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while updating student details.'
    });
  }
}

/**
 * DELETE /api/students/:id
 * D – DELETE: Deletes a student record.
 */
export async function deleteStudent(req, res) {
  try {
    const { id } = req.params;

    // Check if student exists
    const existing = await dbGet('SELECT * FROM students WHERE id = ?', [id]);
    if (!existing) {
      return res.status(404).json({
        success: false,
        message: 'Student record not found or already deleted.'
      });
    }

    // Execute Delete
    await dbExecute('DELETE FROM students WHERE id = ?', [id]);

    return res.status(200).json({
      success: true,
      message: `Student "${existing.full_name}" (ID: ${existing.student_id}) deleted successfully!`
    });
  } catch (error) {
    console.error('Error deleting student:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while deleting student.'
    });
  }
}
