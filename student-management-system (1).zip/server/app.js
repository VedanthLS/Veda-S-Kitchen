import express from 'express';
import path from 'path';
import fs from 'fs';
import studentRoutes from './routes/studentRoutes.js';
import { initDatabase } from './db.js';

const app = express();

// Express Body Parser Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Ensure DB is initialized on requests
app.use(async (req, res, next) => {
  try {
    await initDatabase();
    next();
  } catch (err) {
    next(err);
  }
});

// Serve static frontend assets from public directory
const publicPath = path.join(process.cwd(), 'public');
app.use(express.static(publicPath));

// Health Check API Endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Mount REST API routes for Student Management System
app.use('/api', studentRoutes);

// Catch-all route for unmatched API requests (Always return valid JSON, never HTML)
app.all('/api/*', (req, res) => {
  res.status(404).json({
    success: false,
    message: `API endpoint ${req.method} ${req.path} not found.`
  });
});

// SPA / HTML Page Route Resolution: Support clean URLs (/students -> students.html) and fallback
app.get('*', (req, res) => {
  const reqPath = req.path;

  // Exact file match in public directory
  const directFile = path.join(publicPath, reqPath);
  if (fs.existsSync(directFile) && fs.statSync(directFile).isFile()) {
    return res.sendFile(directFile);
  }

  // Check if adding .html matches a file (e.g. /students -> /public/students.html)
  if (!reqPath.endsWith('.html')) {
    const htmlFile = path.join(publicPath, `${reqPath}.html`);
    if (fs.existsSync(htmlFile) && fs.statSync(htmlFile).isFile()) {
      return res.sendFile(htmlFile);
    }
  }

  // Fallback to primary dashboard index.html
  res.sendFile(path.join(publicPath, 'index.html'));
});

// Global Express Error Handler (Ensures all server errors return JSON to API calls)
app.use((err, req, res, next) => {
  console.error('Server Error:', err);
  if (req.path && req.path.startsWith('/api')) {
    return res.status(500).json({
      success: false,
      message: err.message || 'An internal server error occurred.'
    });
  }
  res.status(500).send('Internal Server Error');
});

export default app;
