import express from 'express';
import {
  getDashboardStats,
  getAllStudents,
  getStudentById,
  createStudent,
  updateStudent,
  deleteStudent
} from '../controllers/studentController.js';

const router = express.Router();

/**
 * REST API Routes for Student Management System
 */

// Dashboard Stats Endpoint
router.get('/stats', getDashboardStats);

// Student CRUD Endpoints
router.get('/students', getAllStudents);
router.get('/students/:id', getStudentById);
router.post('/students', createStudent);
router.put('/students/:id', updateStudent);
router.delete('/students/:id', deleteStudent);

export default router;
