# Student Management System - Web Development Minor Project (CRUD Application)

A professional, modern, responsive web application for managing student records. Demonstrates full **CRUD (Create, Read, Update, Delete)** operations, RESTful API design, form validation, responsive college dashboard UI, and parameterized MySQL database integration.

---

## 📁 Project Structure

```
student-management-system/
│
├── server/
│   ├── server.js               # Main Express.js server entrypoint
│   ├── db.js                   # MySQL database connection pool & fallback driver
│   ├── routes/
│   │   └── studentRoutes.js    # Express REST API routes
│   └── controllers/
│       └── studentController.js # Controllers handling CRUD logic & validation
│
├── public/
│   ├── index.html              # Dashboard Page (Metrics, Analytics, Recent Students)
│   ├── students.html           # Student Directory Page (READ, SEARCH, FILTER, VIEW, EDIT, DELETE)
│   ├── add-student.html        # Add Student Page (CREATE Form with validation)
│   ├── about.html              # About Project Page (CRUD Explanation & Viva Q&A Guide)
│   ├── css/
│   │   └── style.css           # Modern College Dashboard Stylesheet
│   └── js/
│       └── app.js              # Frontend Application JavaScript & API integration
│
├── database/
│   └── student_management.sql  # Complete MySQL database creation script & seed data
│
├── .env.example                # Environment variables template
├── package.json                # Node.js dependencies and scripts
└── README.md                   # Complete documentation & Viva setup guide
```

---

## 🛠️ Technology Stack

* **Frontend:** HTML5, CSS3 (CSS Custom Variables, Flexbox, Grid), JavaScript (ES6+, Fetch API, DOM Manipulation)
* **Backend:** Node.js, Express.js (REST API, Middleware, Static File Server)
* **Database:** MySQL (`mysql2/promise` with parameterized SQL queries)
* **Icons & Fonts:** Font Awesome 6, Plus Jakarta Sans (Google Fonts)

---

## 🚀 Step-by-Step Installation & Setup Guide

### 1. Prerequisites
Ensure you have the following installed on your machine:
* **Node.js** (v18.0.0 or higher)
* **MySQL Server** / **XAMPP** / **WAMP** / **MySQL Workbench**

---

### 2. Database Setup (MySQL)

1. Open **phpMyAdmin** (e.g., `http://localhost/phpmyadmin`) or **MySQL Command Line**.
2. Create a new database named `student_management` OR run the provided SQL script:
   * Open `/database/student_management.sql`.
   * Execute the SQL contents in phpMyAdmin SQL tab or MySQL CLI:
   ```sql
   mysql -u root -p < database/student_management.sql
   ```
3. The SQL script creates the `students` table and inserts sample student records.

#### MySQL Table Schema:
* `id` – `INT AUTO_INCREMENT PRIMARY KEY`
* `student_id` – `VARCHAR(20) UNIQUE NOT NULL`
* `full_name` – `VARCHAR(100) NOT NULL`
* `email` – `VARCHAR(100) UNIQUE NOT NULL`
* `phone` – `VARCHAR(15) NOT NULL`
* `gender` – `VARCHAR(20) NOT NULL`
* `dob` – `DATE NOT NULL`
* `branch` – `VARCHAR(50) NOT NULL`
* `semester` – `INT NOT NULL`
* `section` – `VARCHAR(10) NOT NULL`
* `address` – `TEXT NOT NULL`
* `created_at` – `TIMESTAMP DEFAULT CURRENT_TIMESTAMP`

---

### 3. Environment Configuration

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Update `.env` with your MySQL connection credentials:
   ```env
   PORT=3000
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=your_mysql_password
   DB_NAME=student_management
   ```

---

### 4. Install Dependencies & Start Application

1. Install npm packages:
   ```bash
   npm install
   ```
2. Start the development server:
   ```bash
   npm start
   ```
3. Open your browser and navigate to:
   ```
   http://localhost:3000
   ```

---

## 🧪 Testing Every CRUD Operation

### 1. **C – CREATE (Add Student)**
* Navigate to **Add Student** (`/add-student.html`).
* Fill in all required fields (Student ID, Full Name, Email, Phone, Gender, DOB, Branch, Semester, Section, Address).
* Submit the form. The system performs client-side and backend validation (checking unique Student ID and Email).
* After successful submission, a toast notification appears and the record is inserted into MySQL.

### 2. **R – READ (View & Search Students)**
* Navigate to **Students List** (`/students.html`).
* Search students by name or Student ID using the live search bar.
* Filter student records by **Branch** or **Semester**.
* Click the **View (Eye Icon)** button to view complete student details in a profile modal.

### 3. **U – UPDATE (Edit Student)**
* On the **Students List** page, click the **Edit (Pencil Icon)** button next to any student.
* The edit modal automatically pre-fills the existing student information.
* Modify student details and click **Update Student**.
* The record is updated via `PUT /api/students/:id`, showing a success notification and refreshing the list.

### 4. **D – DELETE (Delete Student)**
* On the **Students List** page, click the **Delete (Trash Icon)** button.
* A confirmation modal appears asking: *"Are you sure you want to delete [Student Name] (ID: [Student ID])?"*
* Click **Confirm Delete**. The record is removed from MySQL via `DELETE /api/students/:id`.

---

## 📡 REST API Documentation

| HTTP Method | API Endpoint | Description | Status Codes |
| :--- | :--- | :--- | :--- |
| **GET** | `/api/stats` | Fetches total student count, branch & semester analytics | `200 OK` |
| **GET** | `/api/students` | Fetches paginated list of students with search/filters | `200 OK` |
| **GET** | `/api/students/:id` | Fetches a single student record by ID | `200 OK`, `404` |
| **POST** | `/api/students` | Creates a new student record (Validation & Unique check) | `201 Created`, `400` |
| **PUT** | `/api/students/:id` | Updates an existing student record | `200 OK`, `400` |
| **DELETE** | `/api/students/:id` | Deletes a student record by ID | `200 OK`, `404` |

---

## 🎓 College Viva Questions & Answers Guide

### Q1: What is Express.js and why is it used?
> **Answer:** Express.js is a web application framework for Node.js. It simplifies building web applications and RESTful APIs by managing routing, request/response objects, middleware, and serving static files.

### Q2: How do parameterized SQL queries prevent SQL Injection?
> **Answer:** Parameterized queries use placeholders (`?`) instead of concatenating user input directly into SQL strings. The database driver treats user input strictly as parameters/data, preventing attackers from injecting executable SQL code.

### Q3: What is the difference between Primary Key and Unique Key?
> **Answer:** A **Primary Key** uniquely identifies each row in a database table and cannot contain NULL values (e.g. `id`). A **Unique Key** ensures that all values in a column are distinct across rows (e.g. `student_id` and `email`).

### Q4: What is REST API?
> **Answer:** REST (Representational State Transfer) is an architectural style for designing networked applications. It uses standard HTTP methods (`GET`, `POST`, `PUT`, `DELETE`) to perform CRUD operations on resources identified by URIs.

---

## 📄 License
This project is created for **Web Development Minor Project** educational purposes.
