# 🚀 Netlify Deployment Guide for Student Management System

This project is **100% pre-configured for Netlify deployment** using **Netlify Serverless Functions** and `serverless-http`.

---

## 📋 Quick 3-Step Deployment Guide

### Step 1: Get the Code
1. In **AI Studio**, click **Settings** (top right) → **Export to GitHub** (or **Download ZIP**).
2. If downloaded as a ZIP file, upload or push it to your GitHub account.

### Step 2: Deploy on Netlify
1. Log into your [Netlify Dashboard](https://app.netlify.com/).
2. Click **Add new site** → **Import an existing project**.
3. Select **GitHub** and choose your repository.
4. Netlify will automatically detect `netlify.toml` with these pre-configured settings:
   - **Publish directory**: `public`
   - **Functions directory**: `netlify/functions`
   - **Node Version**: `20`
5. Click **Deploy site**.

---

## 🛠️ Included Netlify Architecture

- **`netlify.toml`**: Configured to serve static frontend pages from `/public` and automatically route `/api/*` requests to the Netlify serverless handler.
- **`netlify/functions/api.js`**: Wraps your Express REST API with `serverless-http` so all endpoints (`/api/students`, `/api/stats`, `/api/health`) execute smoothly as serverless functions.
- **Database Compatibility**: Features an automatic fallback JSON database engine out-of-the-box. You can also connect a managed MySQL database (e.g. PlanetScale, Aiven, Railway, or AWS RDS) by adding `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` under **Site settings → Environment variables** in Netlify.
