/**
 * Student Management System - Main Frontend JavaScript
 * Handles API calls, CRUD operations, Modals, Validation, Search/Filter, and Dashboard
 */

// Toast Notification Manager
function showToast(message, type = 'success') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const iconClass = type === 'success' ? 'fa-circle-check' : type === 'error' ? 'fa-circle-xmark' : 'fa-triangle-exclamation';
  toast.innerHTML = `<i class="fa-solid ${iconClass}"></i> <span>${message}</span>`;

  container.appendChild(toast);

  // Trigger animation
  setTimeout(() => toast.classList.add('show'), 10);

  // Remove toast after 3.5 seconds
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// API Fetch Helper
async function apiCall(endpoint, options = {}) {
  try {
    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      },
      ...options
    };

    const response = await fetch(endpoint, config);
    const contentType = response.headers.get('content-type');
    
    let result;
    if (contentType && contentType.includes('application/json')) {
      result = await response.json();
    } else {
      const text = await response.text();
      console.error(`Non-JSON response from ${endpoint}:`, text);
      throw new Error(`Server returned unexpected response (${response.status}). Please check backend API.`);
    }

    if (!response.ok) {
      throw new Error(result.message || 'Server request failed');
    }

    return result;
  } catch (error) {
    console.error(`API Error [${endpoint}]:`, error);
    throw error;
  }
}

// Initialize Global UI Components
document.addEventListener('DOMContentLoaded', () => {
  setupSidebarNavigation();
  setupMobileMenuToggle();
});

// Highlight Active Sidebar Link based on Current Page URL
function setupSidebarNavigation() {
  const currentPath = window.location.pathname;
  const navLinks = document.querySelectorAll('.sidebar-link');

  navLinks.forEach((link) => {
    const href = link.getAttribute('href');
    if (
      (currentPath === '/' && href === 'index.html') ||
      currentPath.endsWith(href)
    ) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
}

// Mobile Sidebar Drawer Toggle
function setupMobileMenuToggle() {
  const toggleBtn = document.querySelector('.menu-toggle');
  const sidebar = document.querySelector('.sidebar');

  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('active');
    });

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
      if (
        sidebar.classList.contains('active') &&
        !sidebar.contains(e.target) &&
        !toggleBtn.contains(e.target)
      ) {
        sidebar.classList.remove('active');
      }
    });
  }
}

// ============================================================
// DASHBOARD PAGE LOGIC
// ============================================================

async function loadDashboard() {
  const statsContainer = document.getElementById('dashboard-stats');
  if (!statsContainer) return; // Not on dashboard page

  try {
    const res = await apiCall('/api/stats');
    if (!res.success) return;

    const { totalStudents, branchStats, semesterStats, recentStudents, databaseType } = res.data;

    // 1. Update Stat Cards
    document.getElementById('stat-total-students').textContent = totalStudents;
    document.getElementById('stat-total-branches').textContent = branchStats.length || 0;
    document.getElementById('stat-total-semesters').textContent = semesterStats.length || 0;

    // Update DB Badge
    const dbBadge = document.getElementById('db-status-text');
    if (dbBadge) {
      dbBadge.textContent = databaseType || 'MySQL Active';
    }

    // 2. Render Branch Distribution Progress Bars
    const branchDistList = document.getElementById('branch-distribution');
    if (branchDistList) {
      if (branchStats.length === 0) {
        branchDistList.innerHTML = `<p class="text-muted text-sm">No student data available.</p>`;
      } else {
        branchDistList.innerHTML = branchStats.map((item) => {
          const pct = Math.round((item.count / totalStudents) * 100) || 0;
          return `
            <div class="distribution-item">
              <div class="dist-meta">
                <span>${item.branch}</span>
                <span class="dist-count">${item.count} students (${pct}%)</span>
              </div>
              <div class="progress-bar-bg">
                <div class="progress-fill" style="width: ${pct}%"></div>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // 3. Render Semester Distribution
    const semDistList = document.getElementById('semester-distribution');
    if (semDistList) {
      if (semesterStats.length === 0) {
        semDistList.innerHTML = `<p class="text-muted text-sm">No semester data available.</p>`;
      } else {
        semDistList.innerHTML = semesterStats.map((item) => {
          const pct = Math.round((item.count / totalStudents) * 100) || 0;
          return `
            <div class="distribution-item">
              <div class="dist-meta">
                <span>Semester ${item.semester}</span>
                <span class="dist-count">${item.count} students</span>
              </div>
              <div class="progress-bar-bg">
                <div class="progress-fill" style="width: ${pct}%; background: linear-gradient(90deg, #10b981, #059669);"></div>
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // 4. Render Recent Students Table
    const recentTableBody = document.getElementById('recent-students-tbody');
    if (recentTableBody) {
      if (recentStudents.length === 0) {
        recentTableBody.innerHTML = `<tr><td colspan="6" class="text-center">No student records found.</td></tr>`;
      } else {
        recentTableBody.innerHTML = recentStudents.map((s) => `
          <tr>
            <td>
              <div class="student-cell">
                <div class="student-avatar-sm">${getInitials(s.full_name)}</div>
                <div>
                  <div class="student-name">${escapeHTML(s.full_name)}</div>
                  <div class="student-id-sub">${escapeHTML(s.student_id)}</div>
                </div>
              </div>
            </td>
            <td>${escapeHTML(s.email)}</td>
            <td><span class="badge badge-branch">${escapeHTML(s.branch)}</span></td>
            <td><span class="badge badge-sem">Sem ${s.semester}</span></td>
            <td><span class="badge badge-section">Sec ${escapeHTML(s.section)}</span></td>
            <td>
              <div class="action-btns">
                <button class="btn-icon view" title="View Profile" onclick="openViewModal(${s.id})">
                  <i class="fa-solid fa-eye"></i>
                </button>
              </div>
            </td>
          </tr>
        `).join('');
      }
    }

  } catch (error) {
    showToast('Failed to load dashboard data', 'error');
  }
}

// Helper to extract student initials
function getInitials(name) {
  if (!name) return 'ST';
  const parts = name.trim().split(' ');
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return parts[0].substring(0, 2).toUpperCase();
}

// XSS Prevention Helper
function escapeHTML(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// ============================================================
// STUDENT LIST PAGE LOGIC (READ)
// ============================================================

let currentPage = 1;
let currentSearch = '';
let currentBranch = 'all';
let currentSemester = 'all';

async function loadStudentList(page = 1) {
  const tableBody = document.getElementById('students-tbody');
  if (!tableBody) return; // Not on student list page

  currentPage = page;

  const searchInput = document.getElementById('search-input');
  const branchFilter = document.getElementById('filter-branch');
  const semesterFilter = document.getElementById('filter-semester');

  if (searchInput) currentSearch = searchInput.value.trim();
  if (branchFilter) currentBranch = branchFilter.value;
  if (semesterFilter) currentSemester = semesterFilter.value;

  // Build Query Params
  const queryParams = new URLSearchParams({
    page: currentPage,
    limit: 8,
    search: currentSearch,
    branch: currentBranch,
    semester: currentSemester
  });

  tableBody.innerHTML = `
    <tr>
      <td colspan="8" class="text-center" style="padding: 2rem;">
        <i class="fa-solid fa-spinner fa-spin" style="font-size: 1.5rem; color: var(--primary);"></i>
        <div style="margin-top: 0.5rem; color: var(--text-muted); font-size: 0.85rem;">Loading student records...</div>
      </td>
    </tr>
  `;

  try {
    const res = await apiCall(`/api/students?${queryParams.toString()}`);
    if (!res.success) throw new Error('Failed to load students');

    const students = res.data;
    const pagination = res.pagination;

    // Render Student Table Rows
    if (students.length === 0) {
      tableBody.innerHTML = `
        <tr>
          <td colspan="8" class="text-center" style="padding: 2.5rem; color: var(--text-muted);">
            <i class="fa-solid fa-user-slash" style="font-size: 2rem; margin-bottom: 0.5rem; color: var(--text-light);"></i>
            <div>No student records matched your criteria.</div>
          </td>
        </tr>
      `;
    } else {
      tableBody.innerHTML = students.map((s) => `
        <tr>
          <td><strong style="font-size: 0.85rem; color: var(--primary);">${escapeHTML(s.student_id)}</strong></td>
          <td>
            <div class="student-cell">
              <div class="student-avatar-sm">${getInitials(s.full_name)}</div>
              <div class="student-name">${escapeHTML(s.full_name)}</div>
            </div>
          </td>
          <td>${escapeHTML(s.email)}</td>
          <td>${escapeHTML(s.phone)}</td>
          <td><span class="badge badge-branch">${escapeHTML(s.branch)}</span></td>
          <td><span class="badge badge-sem">Sem ${s.semester}</span></td>
          <td><span class="badge badge-section">${escapeHTML(s.section)}</span></td>
          <td>
            <div class="action-btns">
              <button class="btn-icon view" title="View Complete Details" onclick="openViewModal(${s.id})">
                <i class="fa-solid fa-eye"></i>
              </button>
              <button class="btn-icon edit" title="Edit Student Record" onclick="openEditModal(${s.id})">
                <i class="fa-solid fa-pen-to-square"></i>
              </button>
              <button class="btn-icon delete" title="Delete Student Record" onclick="openDeleteModal(${s.id}, '${escapeHTML(s.full_name)}', '${escapeHTML(s.student_id)}')">
                <i class="fa-solid fa-trash-can"></i>
              </button>
            </div>
          </td>
        </tr>
      `).join('');
    }

    // Render Pagination Info & Controls
    renderPagination(pagination);

    // Update total count badge
    const countBadge = document.getElementById('total-records-count');
    if (countBadge) countBadge.textContent = `${pagination.total} Records`;

  } catch (error) {
    showToast('Error fetching student list', 'error');
  }
}

// Render Pagination Controls
function renderPagination(pagination) {
  const paginationWrapper = document.getElementById('pagination-container');
  if (!paginationWrapper) return;

  const { page, totalPages, total, limit } = pagination;
  const startCount = total === 0 ? 0 : (page - 1) * limit + 1;
  const endCount = Math.min(page * limit, total);

  let pageBtnsHTML = '';
  for (let i = 1; i <= totalPages; i++) {
    pageBtnsHTML += `
      <button class="page-btn ${i === page ? 'active' : ''}" onclick="loadStudentList(${i})">
        ${i}
      </button>
    `;
  }

  paginationWrapper.innerHTML = `
    <div class="pagination-info">
      Showing <strong>${startCount}-${endCount}</strong> of <strong>${total}</strong> students
    </div>
    <div class="pagination-btns">
      <button class="page-btn" ${page <= 1 ? 'disabled' : ''} onclick="loadStudentList(${page - 1})">
        <i class="fa-solid fa-chevron-left"></i>
      </button>
      ${pageBtnsHTML}
      <button class="page-btn" ${page >= totalPages ? 'disabled' : ''} onclick="loadStudentList(${page + 1})">
        <i class="fa-solid fa-chevron-right"></i>
      </button>
    </div>
  `;
}

// Debounce Helper for Search Input
let searchTimeout = null;
function handleSearchInput() {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => {
    loadStudentList(1);
  }, 350);
}

// ============================================================
// VIEW STUDENT MODAL LOGIC
// ============================================================

async function openViewModal(id) {
  const modalBackdrop = document.getElementById('view-modal');
  const modalContent = document.getElementById('view-modal-content');
  if (!modalBackdrop || !modalContent) return;

  modalContent.innerHTML = `<div class="text-center" style="padding: 2rem;"><i class="fa-solid fa-spinner fa-spin" style="font-size: 1.5rem; color: var(--primary);"></i></div>`;
  modalBackdrop.classList.add('show');

  try {
    const res = await apiCall(`/api/students/${id}`);
    if (!res.success) throw new Error('Student not found');

    const s = res.data;

    modalContent.innerHTML = `
      <div class="profile-card-header">
        <div class="profile-avatar-lg">${getInitials(s.full_name)}</div>
        <div class="profile-meta">
          <h3>${escapeHTML(s.full_name)}</h3>
          <div style="display: flex; gap: 0.5rem; margin-top: 0.4rem;">
            <span class="badge badge-branch">${escapeHTML(s.branch)}</span>
            <span class="badge badge-sem">Semester ${s.semester}</span>
            <span class="badge badge-section">Section ${escapeHTML(s.section)}</span>
          </div>
        </div>
      </div>

      <div class="profile-detail-grid">
        <div class="detail-item">
          <div class="detail-label">Student ID</div>
          <div class="detail-value" style="color: var(--primary); font-weight: 700;">${escapeHTML(s.student_id)}</div>
        </div>
        <div class="detail-item">
          <div class="detail-label">Email Address</div>
          <div class="detail-value">${escapeHTML(s.email)}</div>
        </div>
        <div class="detail-item">
          <div class="detail-label">Phone Number</div>
          <div class="detail-value">${escapeHTML(s.phone)}</div>
        </div>
        <div class="detail-item">
          <div class="detail-label">Gender</div>
          <div class="detail-value">${escapeHTML(s.gender)}</div>
        </div>
        <div class="detail-item">
          <div class="detail-label">Date of Birth</div>
          <div class="detail-value">${escapeHTML(s.dob)}</div>
        </div>
        <div class="detail-item">
          <div class="detail-label">Enrolled Date</div>
          <div class="detail-value">${s.created_at ? new Date(s.created_at).toLocaleDateString() : 'N/A'}</div>
        </div>
        <div class="detail-item" style="grid-column: span 2;">
          <div class="detail-label">Residential Address</div>
          <div class="detail-value">${escapeHTML(s.address)}</div>
        </div>
      </div>
    `;
  } catch (error) {
    showToast('Failed to load student details', 'error');
    closeModal('view-modal');
  }
}

// ============================================================
// EDIT STUDENT MODAL LOGIC (UPDATE)
// ============================================================

async function openEditModal(id) {
  const modalBackdrop = document.getElementById('edit-modal');
  if (!modalBackdrop) return;

  try {
    const res = await apiCall(`/api/students/${id}`);
    if (!res.success) throw new Error('Student not found');

    const s = res.data;

    document.getElementById('edit-id').value = s.id;
    document.getElementById('edit-student-id').value = s.student_id;
    document.getElementById('edit-full-name').value = s.full_name;
    document.getElementById('edit-email').value = s.email;
    document.getElementById('edit-phone').value = s.phone;
    document.getElementById('edit-gender').value = s.gender;
    document.getElementById('edit-dob').value = s.dob ? s.dob.split('T')[0] : '';
    document.getElementById('edit-branch').value = s.branch;
    document.getElementById('edit-semester').value = s.semester;
    document.getElementById('edit-section').value = s.section;
    document.getElementById('edit-address').value = s.address;

    modalBackdrop.classList.add('show');
  } catch (error) {
    showToast('Failed to load student details for editing', 'error');
  }
}

async function submitEditStudent(event) {
  event.preventDefault();

  const id = document.getElementById('edit-id').value;
  const payload = {
    student_id: document.getElementById('edit-student-id').value.trim(),
    full_name: document.getElementById('edit-full-name').value.trim(),
    email: document.getElementById('edit-email').value.trim(),
    phone: document.getElementById('edit-phone').value.trim(),
    gender: document.getElementById('edit-gender').value,
    dob: document.getElementById('edit-dob').value,
    branch: document.getElementById('edit-branch').value,
    semester: document.getElementById('edit-semester').value,
    section: document.getElementById('edit-section').value,
    address: document.getElementById('edit-address').value.trim()
  };

  try {
    const res = await apiCall(`/api/students/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });

    if (res.success) {
      showToast('Student record updated successfully!', 'success');
      closeModal('edit-modal');
      loadStudentList(currentPage);
      if (document.getElementById('dashboard-stats')) {
        loadDashboard();
      }
    }
  } catch (error) {
    showToast(error.message || 'Failed to update student', 'error');
  }
}

// ============================================================
// DELETE STUDENT MODAL LOGIC (DELETE)
// ============================================================

let studentToDeleteId = null;

function openDeleteModal(id, name, studentId) {
  studentToDeleteId = id;
  const modalBackdrop = document.getElementById('delete-modal');
  const targetText = document.getElementById('delete-target-info');

  if (targetText) {
    targetText.innerHTML = `Are you sure you want to delete <strong>${escapeHTML(name)}</strong> (ID: <strong>${escapeHTML(studentId)}</strong>)? This action cannot be undone.`;
  }

  if (modalBackdrop) modalBackdrop.classList.add('show');
}

async function confirmDeleteStudent() {
  if (!studentToDeleteId) return;

  try {
    const res = await apiCall(`/api/students/${studentToDeleteId}`, {
      method: 'DELETE'
    });

    if (res.success) {
      showToast('Student record deleted successfully!', 'success');
      closeModal('delete-modal');
      studentToDeleteId = null;

      // Refresh page data
      if (document.getElementById('students-tbody')) {
        loadStudentList(currentPage);
      }
      if (document.getElementById('dashboard-stats')) {
        loadDashboard();
      }
    }
  } catch (error) {
    showToast(error.message || 'Failed to delete student', 'error');
  }
}

// Modal Close Helper
function closeModal(modalId) {
  const modalBackdrop = document.getElementById(modalId);
  if (modalBackdrop) {
    modalBackdrop.classList.remove('show');
  }
}

// ============================================================
// ADD STUDENT FORM LOGIC (CREATE)
// ============================================================

async function submitAddStudent(event) {
  event.preventDefault();

  const form = event.target;
  let isValid = true;

  // Clear previous error states
  form.querySelectorAll('.form-control').forEach((input) => {
    input.classList.remove('is-invalid');
  });

  const getVal = (id) => {
    const el = form.querySelector(`#${id}`) || document.getElementById(id);
    return el ? el.value.trim() : '';
  };

  const payload = {
    student_id: getVal('student_id'),
    full_name: getVal('full_name'),
    email: getVal('email'),
    phone: getVal('phone'),
    gender: getVal('gender'),
    dob: getVal('dob'),
    branch: getVal('branch'),
    semester: getVal('semester'),
    section: getVal('section'),
    address: getVal('address')
  };

  // Client-Side Validation
  if (!payload.student_id) {
    markInvalidInForm(form, 'student_id', 'Student ID is required');
    isValid = false;
  }
  if (!payload.full_name) {
    markInvalidInForm(form, 'full_name', 'Full Name is required');
    isValid = false;
  }
  if (!payload.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email)) {
    markInvalidInForm(form, 'email', 'Valid Email address is required');
    isValid = false;
  }
  if (!payload.phone || !/^[0-9+\-\s]{10,15}$/.test(payload.phone)) {
    markInvalidInForm(form, 'phone', 'Valid 10–15 digit phone number is required');
    isValid = false;
  }
  if (!payload.gender) {
    markInvalidInForm(form, 'gender', 'Gender selection is required');
    isValid = false;
  }
  if (!payload.dob) {
    markInvalidInForm(form, 'dob', 'Date of Birth is required');
    isValid = false;
  }
  if (!payload.branch) {
    markInvalidInForm(form, 'branch', 'Branch selection is required');
    isValid = false;
  }
  if (!payload.semester || payload.semester < 1 || payload.semester > 8) {
    markInvalidInForm(form, 'semester', 'Semester must be between 1 and 8');
    isValid = false;
  }
  if (!payload.section) {
    markInvalidInForm(form, 'section', 'Section is required');
    isValid = false;
  }
  if (!payload.address) {
    markInvalidInForm(form, 'address', 'Address is required');
    isValid = false;
  }

  if (!isValid) {
    showToast('Please fix all highlighted errors in the form.', 'warning');
    return;
  }

  const submitBtn = form.querySelector('button[type="submit"]');
  const origBtnHTML = submitBtn.innerHTML;
  submitBtn.disabled = true;
  submitBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Saving...`;

  try {
    const res = await apiCall('/api/students', {
      method: 'POST',
      body: JSON.stringify(payload)
    });

    if (res.success) {
      showToast('Student record created successfully!', 'success');
      form.reset();

      // Close modal if open
      closeModal('add-modal');

      // Instantly refresh student directory list if on students page
      if (document.getElementById('students-tbody')) {
        loadStudentList(1);
      }

      // Instantly refresh dashboard analytics if on dashboard page
      if (document.getElementById('dashboard-stats')) {
        loadDashboard();
      }

      // Show success alert card if on add-student.html page
      const alertBox = document.getElementById('add-success-alert');
      if (alertBox) {
        alertBox.style.display = 'flex';
        setTimeout(() => {
          alertBox.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    }
  } catch (error) {
    showToast(error.message || 'Failed to create student record', 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = origBtnHTML;
  }
}

function openAddModal() {
  const modal = document.getElementById('add-modal');
  if (modal) {
    const form = modal.querySelector('form');
    if (form) form.reset();
    openModal('add-modal');
  } else {
    window.location.href = 'add-student.html';
  }
}

function markInvalidInForm(form, fieldId, errorMsg) {
  const field = form.querySelector(`#${fieldId}`) || document.getElementById(fieldId);
  if (field) {
    field.classList.add('is-invalid');
    const feedback = field.parentElement.querySelector('.error-feedback');
    if (feedback) feedback.textContent = errorMsg;
  }
}

function markInvalid(fieldId, errorMsg) {
  const field = document.getElementById(fieldId);
  if (field) {
    field.classList.add('is-invalid');
    const feedback = field.parentElement.querySelector('.error-feedback');
    if (feedback) feedback.textContent = errorMsg;
  }
}
