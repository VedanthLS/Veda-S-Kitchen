-- ============================================================
-- Student Management System - MySQL Database Schema & Seed Data
-- Web Development Minor Project
-- ============================================================

-- Create database if it doesn't already exist
CREATE DATABASE IF NOT EXISTS student_management;
USE student_management;

-- Drop table if exists (For clean reset during development/testing)
DROP TABLE IF EXISTS students;

-- Create students table
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    gender VARCHAR(20) NOT NULL,
    dob DATE NOT NULL,
    branch VARCHAR(50) NOT NULL,
    semester INT NOT NULL,
    section VARCHAR(10) NOT NULL,
    address TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- Initial Sample Seed Data (For Testing & College Demo)
-- ============================================================

INSERT INTO students (student_id, full_name, email, phone, gender, dob, branch, semester, section, address) VALUES
('CS202601', 'Aarav Sharma', 'aarav.sharma@example.com', '9876543210', 'Male', '2004-05-15', 'Computer Science', 5, 'A', '102 Green Park Avenue, New Delhi'),
('IT202602', 'Priya Patel', 'priya.patel@example.com', '9876543211', 'Female', '2003-08-22', 'Information Technology', 6, 'B', '45 MG Road, Bengaluru, Karnataka'),
('EC202603', 'Rohan Verma', 'rohan.verma@example.com', '9876543212', 'Male', '2004-01-10', 'Electronics & Comm', 4, 'A', '78 Lake View Enclave, Hyderabad'),
('ME202604', 'Ananya Roy', 'ananya.roy@example.com', '9876543213', 'Female', '2005-03-30', 'Mechanical Eng', 3, 'C', '12 Salt Lake Sector V, Kolkata'),
('CE202605', 'Vikram Singh', 'vikram.singh@example.com', '9876543214', 'Male', '2002-11-05', 'Civil Eng', 8, 'A', '304 Park Street, Jaipur, Rajasthan'),
('CS202606', 'Sneha Kulkarni', 'sneha.kulkarni@example.com', '9876543215', 'Female', '2004-09-18', 'Computer Science', 5, 'B', '56 FC Road, Pune, Maharashtra'),
('IT202607', 'Aditya Nair', 'aditya.nair@example.com', '9876543216', 'Male', '2005-02-14', 'Information Technology', 2, 'A', '89 Marine Drive, Kochi, Kerala'),
('EC202608', 'Kavya Reddy', 'kavya.reddy@example.com', '9876543217', 'Female', '2003-12-01', 'Electronics & Comm', 7, 'B', '201 Jubilee Hills, Hyderabad'),
('CS202609', 'Siddharth Gupta', 'siddharth.gupta@example.com', '9876543218', 'Male', '2004-07-25', 'Computer Science', 3, 'A', '15 Hazratganj, Lucknow, UP'),
('ME202610', 'Meera Joshi', 'meera.joshi@example.com', '9876543219', 'Female', '2005-06-12', 'Mechanical Eng', 1, 'A', '40 Race Course Road, Ahmedabad, Gujarat');

-- Verify inserted data
SELECT * FROM students;
